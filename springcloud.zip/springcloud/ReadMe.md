# 学习 SpringCloud
[【狂神说Java】SpringCloud最新教程IDEA版](https://www.bilibili.com/video/BV1jJ411S7xr?p=5&spm_id_from=pageDriver)

## 补差不缺
监控框架： skywalking
其他框架： sentinel

## Eureka
* Eureka 是 Netflix 的子模块